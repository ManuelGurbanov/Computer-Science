#include "ej2.h"

void combinarImagenes(uint8_t *src_a, uint8_t *src_b, uint8_t *dst, uint32_t width, uint32_t height)
{
}
