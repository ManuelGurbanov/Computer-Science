#include "ej2.h"

void mezclarColores_c( uint8_t *X, uint8_t *Y, uint32_t width, 
                            uint32_t height){
    
}
